<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBlueDartDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blue_dart_details', function (Blueprint $table) {
            $table->id();
            $table->string('salesorder_id');
            $table->string('awb_no');
            $table->string('token_number')->nullable();
            $table->string('invoice_id')->nullable();
            $table->string('total_amount')->nullable();
            $table->string('phone_number')->nullable();
            $table->dateTime('invoice_date')->nullable();
            $table->dateTime('order_date')->nullable();
            $table->text('ship_to')->nullable();
            $table->string('cluster_code')->nullable();
            $table->string('destination_area')->nullable();
            $table->string('destination_location')->nullable();
            $table->string('total_quantity')->nullable();
            $table->text('items_details')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('blue_dart_details');
    }
}
