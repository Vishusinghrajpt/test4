<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InventryController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ShiprocketController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
   return redirect()->route('inventryList');;
})->middleware(['auth']);


Route::get('/generate-invoice', [InvoiceController::class, 'generateInvoice'])->name('generateInvoice');
Route::get('/getBlueDartJwtToken',[InventryController::class, 'getBlueDartJwtToken'])->name('getBlueDartJwtToken');
// cancel_shipment
Route::prefix('admin')->middleware('auth')->group(function () {
    Route::controller(InventryController::class)->group(function () {
        // getBlueDartJwtToken
        Route::get('/zohoUpdate', 'zohoUpdate')->name('zohoUpdate');
        Route::get('/zoho-inventry-list', 'inventryList')->name('inventryList');
        Route::post('/GetServicesforPincode', 'checkServiceForPincode')->name('GetServicesforPincode');
        Route::post('/GenerateWayBill', 'GenerateWayBill')->name('ship_blue_dart');
    });
});

Route::prefix('shiprocket')->middleware('auth')->group(function () {
    Route::controller(ShiprocketController::class)->group(function () {
        Route::post('/GetServicesforPincode', 'checkServiceForPincode')->name('GetServices');
        Route::post('/create_shipment', 'create_shipment')->name('ship_by_shiprocket');
        Route::get('/cancel_shipment', 'cancelShipment')->name('cancel_shipment');
    });
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';
