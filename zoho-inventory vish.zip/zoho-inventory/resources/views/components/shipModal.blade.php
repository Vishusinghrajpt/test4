@props(['message'=>null,'id'=>null,'title'=>null,'action'=>null])
<div class="modal fade" id="modal_{{$id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="display: flex; justify-content: space-between;">
        <h5 class="modal-title" id="exampleModalLongTitle">{{$title}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="{{$action}}" method="POST" id="form_{{$id}}"  onsubmit="formSubmit(this, event,'{{$id}}')">
          @csrf
          <input type="hidden" name="salesorder_id" id="salesorder_id_{{$id}}" />
          <div class="form-group">
              <label for="breadth">Breadth (in cm):</label>
              <input type="text" name="breadth" class="form-control" id="breadth" placeholder="Enter Breadth" required>
          </div>

          <div class="form-group">
              <label for="height">Height (in cm):</label>
              <input type="text" name="height" class="form-control" id="height" placeholder="Enter Height" required>
          </div>

          <div class="form-group">
              <label for="length">Length (in cm):</label>
              <input type="text" name="length" class="form-control" id="length" placeholder="Enter Length" required>
          </div>

          <div class="form-group">
              <label for="weight">Weight (in kg):</label>
              <input type="text" name="weight" class="form-control" id="weight" placeholder="Enter Weight" required>
          </div>

          <div class="form-group available_{{$id}}">
              <label>Available Services:</label><br>

            <div class="checkBoxGroup_{{$id}}">
      
            </div>
          </div>
         <div class="modal-footer footer-{{$id}}">
           <button type="submit" id="submit_{{$id}}" class="btn btn-primary">Create Shipment</button>
           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </div>
        </form>
      </div>
    {{--  <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>--}}
    </div>
  </div>
</div>