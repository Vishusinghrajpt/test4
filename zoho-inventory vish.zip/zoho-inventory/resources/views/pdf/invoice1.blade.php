<!DOCTYPE html>
<html>
<head>
<!-- <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet"> -->
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
        }
        .invoice-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .invoice-table th, .invoice-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        .barcode {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>

<div class="invoice-header">
    <h2>Invoice</h2>
    <p>Invoice Number: {{ $invoiceNumber }}</p>
    <p>Date: {{ $date }}</p>
</div>



<div class="barcode">
    <p>Barcode for Invoice</p>
    {!! DNS1D::getBarcodeHTML($invoiceNumber, 'C39') !!}
    <p>{{ $invoiceNumber }}</p>
</div>

</body>
</html>
