<style>
  table {
    font-family: "Roboto", sans-serif;

  }
</style>
<table cellspacing="0" cellpadding="5" width="100%" border="1px">
  <tr>
    <td>
      <strong>Ship to</strong>: {{$ship_to ?? ''}}<br />Mob: {{$phone ?? ''}}
    </td>
    <td align="center">
      <img src="https://servdharm.com/cdn/shop/files/servdharm-logo_600x.webp" alt="Logo">
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center" style="text-align: center;">
      <p>
        <strong>Bluedart: {{$awb_no ?? ''}}</strong>
      </p>
      <div style="margin: 0 auto; display: inline-block;">
        {!! DNS1D::getBarcodeHTML($awb_no, 'C39') !!}
      </div>
    </td>
  </tr>
  <tr>
    <td align="center">
      <strong>
        Amount to be collected<br />COD<br />Rs {{$amount ?? 0}}.00<br />
        ({{$amountInString ?? ''}})
      </strong>
    </td>
    <td>
      <table border="0" width="100%" cellspacing="0" cellpadding="3">
        <tr>
          <td><strong>Route Code:</strong></td>
          <td align="right">{{$route ?? ''}}</td>
        </tr>
        <tr>
          <td><strong>Order Date:</strong></td>
          <td align="right">{{date('M d, Y', strtotime($order_date)) ?? ''}}</td>
        </tr>
        <tr>
          <td><strong>Invoice Number:</strong></td>
          <td align="right">{{$invoice_id ?? ''}}</td>
        </tr>
        <tr>
          <td><strong>Invoice Date:</strong></td>
          <td align="right">{{date('M d, Y', strtotime($invoice_date)) ?? ''}}</td>
        </tr>
        <tr>
          <td><strong>Pieces:</strong></td>
          <td align="right">{{$total_quantity ?? ''}}</td>
        </tr>
      </table>
    </td>

  </tr>
  <tr>
    <td colspan="2" align="center">
      Order Id: {{$salesorder_id ?? ''}}
    </td>
  </tr>
  <tr>
    <td colspan="2" height="200px">
      <table class="table table-bordered" width="100%" cellspacing="0" cellpadding="3">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>SKU</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          @foreach(json_decode($items_details, true) as $item)
          @php
          $taxtData = $item['line_item_taxes'][0] ?? null;
          $total_amount =$item['item_total']+ ($taxtData['tax_amount'] ?? 0);
          @endphp
          <tr>
            <td>{{$item['name'] ?? 'name'}}</td>
            <td>{{$item['sku'] ?? 'sku'}}</td>
            <td>{{$item['quantity'] ?? 'qty'}}</td>
            <td>{{number_format($item['rate'],2) ?? 'rate'}}</td>
            <td>{{number_format($total_amount,2) ?? 'total'}}</td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </td>
  </tr>
  <tr>
    <td>Order Total: </td>
    <td align="right">Rs {{number_format($amount,2) ?? ''}}</td>
  </tr>
  <tr>
    <td colspan="2">
      <strong>
        <p>Return Address:
      </strong> D53, Nangal Dewat, Sector D, Vasant Kunj, New Delhi, South
      West Delhi, South West Delhi, Delhi, India, 110070</p>
      <p><strong>GSTIN No.:</strong> 07AASFT1911F1Z5</p>
    </td>
  </tr>
</table>