@extends('layouts.default')
@section('title') Zoho + Blue Dart @endsection

@push('css')
<style type="text/css">
    .table-bordered>thead>tr>th a {
        display: flex;
        justify-content: space-between;
        color: black;
    }

    .ShorderByStatusSec {
        display: flex;
        justify-content: space-between;
        align-items: center;

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 0;

            label {
                width: 233px;
                margin-bottom: 0;
            }
        }
    }

    .alert {
        padding: 0px 5px;
        margin: 0;
    }
    .dropdown-menu > li > a{
        color:white !important;
    }
    .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus{
        color: black !important;
    }
</style>
@endpush
@section('content')

<div id="page-wrapper1">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="panel panel-default">
                    <div class="panel-heading ShorderByStatusSec">
                        List Of Orders
                        <div class="form-group">
                            <label for="ShorderByStatus">Filter By Zoho Status:</label>
                            <select class="form-control" id="ShorderByStatus" placeholder="" onchange="shortByStatus(this.value)">
                                <option value="">Select Order Status</option>
                                <option value="Confirmed">Confirmed</option>
                                <option value="Fulfilled">Fulfilled</option>
                                <option value="Void">Void</option>
                                <option value="Draft">Draft</option>
                            </select>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">

                            <table class="table table-striped table-bordered table-hover" data-show-toggle="true">
                                <thead>
                                    <tr>
                                        <th>
                                            <a class="ShortBy" href="javascript:void(0)" onclick="sortBy('salesorder_number')">
                                                Sales Order Id
                                                <i id="icon_salesorder_number" class="fa fa-sort-asc"></i>
                                            </a>
                                        </th>
                                        <th>
                                            <a class="ShortBy" href="javascript:void(0)" onclick="sortBy('customer_name')">
                                                Customer Name
                                                <i id="icon_customer_name" class="fa fa-sort-asc"></i>
                                            </a>
                                        </th>
                                        <th>Email</th>
                                        <th>
                                            <a class="ShortBy" href="javascript:void(0)" onclick="sortBy('total')">
                                                Total Amount
                                                <i id="icon_total" class="fa fa-sort-asc"></i>
                                            </a>
                                        </th>
                                        <th>Shipping Status</th>
                                        <th>Zoho Status</th>
                                        <th style="width: 100px;">Manage Shipment</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($datas as $data)
                                    @php
                                    $salesorder_id = $data['salesorder_id'];
                                    @endphp
                                    <tr>
                                        <td>#{{$data['salesorder_number'] ?? ''}}</td>
                                        <td>{{$data['customer_name'] ?? ''}}</td>
                                        <td>{{$data['email'] ?? ''}}</td>
                                        <td>Rs. {{ number_format($data['total'],2) ?? ''}}</td>
                                        <td>{{$data['shipped_status'] ?? ''}}</td>
                                        <td>{{$data['status'] ?? ''}}</td>
                                        <td align="center">
                                            @if($data['invoiced_status'] == 'invoiced' && ($data['order_status'] == 'confirmed' || $data['order_status'] == 'closed') )
                                            @if($data['lable'])

                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                                                    Action
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li class="btn">
                                                        <a class="btn btn-primary text-white" href="{{ $data['lable_url'] }}">
                                                            Download Label
                                                        </a>
                                                    </li>
                                                    <li class="btn">
                                                        <a class="btn btn-danger" href="javascript:void(0)" onclick="cancelShipment('{{ $salesorder_id }}')">
                                                            Cancel Shipment
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            @else
                                            @if($data['shipped_status'] == 'pending')
                                            <!-- <button class="btn btn-success" onclick="shipModel('{{ $salesorder_id }}')" style="margin-bottom:3px;">Ship By Blue Dart</button>
                                                     <button class="btn btn-info" onclick="shipByShiprocket('{{ $salesorder_id }}')">Ship By Shiprocket</button> -->
                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                                                    Ship
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li class="btn"><a class="btn btn-success" href="javascript:void(0)" onclick="shipModel('{{ $salesorder_id }}','blueDart')">Ship By Blue Dart</a></li>
                                                    <li class="btn"><a class="btn btn-info" href="javascript:void(0)" onclick="shipByShiprocket('{{ $salesorder_id }}')">Ship By Shiprocket</a></li>
                                                </ul>
                                            </div>
                                            @else
                                            <span class="alert alert-warning">Shipped</span>
                                            @endif
                                            @endif
                                            @else
                                            @if($data['invoiced_status'] != 'invoiced')
                                            <span class="alert alert-info">Not Invoiced</span>
                                            @elseif($data['order_status'] != 'confirmed')
                                            <span class="alert alert-warning">Order Not confirmed</span>
                                            @endif
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="pagination" style="display:flex;justify-content:end;">
                                @if ($currentPage > 1)
                                <a class="btn btn-success" href="javascript:void(0)" style="margin-right: 10px;" onclick="pagination('{{$currentPage -1}}')">Previous</a>
                                @endif

                                @if ($currentPage)
                                <a class="btn btn-success ms-3" href="javascript:void(0)" onclick="pagination('{{$currentPage + 1}}')">Next</a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<x-shipModal message="test" id="blueDart" title="Blue Dart Shipment" action="{{ route('ship_blue_dart') }}" />
<!-- shipByShiprocket -->
<x-shipModal message="test" id="shiprocket" title="Shiprocket Shipment" action="{{ route('GetServices') }}" />
@endsection
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
@push('js')
<script type="text/javascript">
    function shipByShiprocket(salesorder_id, modal_id = "shiprocket") {
        $('.checkBoxGroup_' + modal_id).html('');
        $('#salesorder_id_' + modal_id).val(salesorder_id);
        $('.available_' + modal_id).hide();
        $('#submit_' + modal_id).html('Check Courier Options')
        $('#form_' + modal_id).attr('action', "{{ route('GetServices') }}")
        $('#modal_' + modal_id).modal('show');
    }

    function shipModel($data, modal_id) {
        $.ajax({
            url: "{{ route('GetServicesforPincode') }}",
            type: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                salesorder_id: $data,
            },
            success: function(response) {
                var data = response.original;
                var checkBoxGroup = '';
                if (data.status_code == 2) {
                    Swal.fire({
                        icon: 'error',
                        title: data.data.title ?? 'Error',
                        text: 'No Services Available For The Selected Pincode.',
                    });
                } else {
                    if (data.data.air === "Yes") {
                        checkBoxGroup += `<div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidAirOutbound" value="air" required>
                        <label class="form-check-label" for="eTailPrePaidAirOutbound">Air</label>
                    </div>`;
                    }

                    if (data.data.surface === "Yes") {
                        checkBoxGroup += `<div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundInbound" value="surface" required>
                        <label class="form-check-label" for="eTailPrePaidGroundInbound">Ground / Surface</label>
                    </div>`;
                    }

                    if (data.data.dart === "Yes") {
                        checkBoxGroup += `<div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundOutbound" value="dart" required>
                        <label class="form-check-label" for="eTailPrePaidGroundOutbound">Dart</label>
                    </div>`;
                    }
                    $('.checkBoxGroup_' + modal_id).html(checkBoxGroup);
                    $('#modal_' + modal_id).modal('show');
                }

            },
            error: function(xhr, status, error) {
                console.log('Error: ', error);
                let response = xhr.responseJSON;
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message || 'An unexpected error occurred.',
                });
            }
        });
    }

    function formSubmit(formData, e, modal_id) {
        e.preventDefault();
        var serilizFormData = $(formData).serialize();
        $.ajax({
            url: formData.action,
            type: formData.method,
            data: serilizFormData,
            success: function(response) {
                var massage = response.message;
                if (response.status_code == 1) {
                    $('#modal' + modal_id).modal('hide');
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: massage ?? 'Order has been shipped successfully.',
                    }).then(() => {
                        location.reload();
                    });
                } else if (response.status_code == 3) {
                    $('.available_' + modal_id).show();
                    $('#submit_' + modal_id).html('Create Shipment')
                    $('.checkBoxGroup_' + modal_id).html(response.data);
                    $('#form_' + modal_id).attr('action', "{{ route('ship_by_shiprocket') }}")
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: massage ?? 'An unexpected error occurred.',
                    });
                }
            },
            error: function(xhr, status, error) {
                console.log('Error: ', error);
                let response = xhr.responseJSON;
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message || 'An unexpected error occurred.',
                });
            }
        });
    }



    let currentSortColumn = "";
    let currentSortOrder = "A";

    function getURLParameter(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    function initializeSorting() {
        currentSortColumn = getURLParameter('sort_column_name') || "";
        currentSortOrder = getURLParameter('sort_order') || "A";

        if (currentSortColumn) {
            updateSortIcons(currentSortColumn, currentSortOrder);
        }
    }

    function sortBy(column) {
        if (currentSortColumn === column) {
            currentSortOrder = currentSortOrder === "A" ? "D" : "A";
        } else {
            currentSortOrder = "A";
        }
        currentSortColumn = column;

        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('sort_column_name', column);
        urlParams.set('sort_order', currentSortOrder);

        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.location.href = newUrl;
    }

    function updateSortIcons(column, sortOrder) {
        const icon = document.getElementById(`icon_${column}`);
        if (sortOrder === "A") {
            icon.classList.add("fa-sort-asc");
        } else {
            icon.classList.add("fa-sort-desc");
        }
    }

    function shortByStatus(value) {
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('filter_by', value);
        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.location.href = newUrl;
    }

    function pagination(page) {
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('page', page);
        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.location.href = newUrl;
    }
    window.onload = initializeSorting;

    function cancelShipment(salesorder_id)
    {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, cancel it!'
        }).then((result) => {
            if (result.isConfirmed) {
                var url = "{{ route('cancel_shipment', ['salesorder_id' => '__ID__']) }}"; 
                url = url.replace('__ID__', salesorder_id); 
                window.location.href = url;
                // window.location.href = "{{ route('cancel_shipment', ['salesorder_id' => "+salesorder_id+"]) }}";
            }
        });
    }
</script>

@endpush