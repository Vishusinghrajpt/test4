<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use Milon\Barcode\DNS1D;
use App\Models\BlueDartDetail;
use NumberToWords\NumberToWords;

class InvoiceController extends Controller
{
    public function generateInvoice(Request $request)
    {

        if($request->salesorder_id){
            $lable = BlueDartDetail::where('salesorder_id',$request->salesorder_id)->first();
            
            if(is_null($lable)){
            return redirect()->back()->with('error', 'No ship to address found for this sales order.');
            }
            $ship_to_data = json_decode($lable->ship_to);
            $lable->ship_to = $ship_to_data->address . ' ' . $ship_to_data->street2 . ' ' . $ship_to_data->city . ' ' . $ship_to_data->state . '-' . $ship_to_data->zip;
            $lable->zip = $ship_to_data->zip;
            $numberToWords = new NumberToWords();
            $numberTransformer = $numberToWords->getNumberTransformer('en');
            $amount = (int)$lable->total_amount ?? 0;
            $lable->amountInString = $numberTransformer->toWords($amount);
            $lable->route =  $lable->cluster_code ? ($lable->cluster_code.'/'.$lable->destination_area.'/'.$lable->destination_location)  : ''.$lable->destination_area.'/'.$lable->destination_location;
            // $lable = json_encode($lable);
        
//   dd(json_decode($lable->items_details));
            $invoiceData = [
                'ship_to' => $lable->ship_to,
                'date' => now()->format('Y-m-d'),
                'amount' => $amount,
                'amountInString' =>$lable->amountInString,
                'salesorder_id' => $lable->salesorder_id,
                'awb_no' => $lable->awb_no,
                'invoice_id' => $lable->invoice_id,
                'phone' => $lable->phone_number,
                'invoice_date' => $lable->invoice_date,
                'order_date' => $lable->order_date,
                'route' => $lable->route,
                'total_quantity' => $lable->total_quantity,
                'items_details' =>  $lable->items_details,
            ];
// return view('pdf.invoice', $invoiceData);
            $pdf = Pdf::loadView('pdf.invoice', $invoiceData);

            return $pdf->download('invoice_' . $lable->awb_no . '.pdf');
        }
    }
}
