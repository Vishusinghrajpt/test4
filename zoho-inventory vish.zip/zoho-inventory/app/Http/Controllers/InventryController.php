<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ZohoInventoryService;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;
use App\Models\BlueDartDetail;
use function Ramsey\Uuid\v1;

class InventryController extends Controller
{
    protected $zohoService;
    protected $jwtToken;
    protected $BearerToken;

    public function __construct(ZohoInventoryService $zohoService)
    {
        $this->zohoService = $zohoService;
        $file = storage_path('app/blueDartJwtToken.json');
        $JwtToken = json_decode(file_get_contents($file),true);
        $this->jwtToken = $JwtToken['JWTToken'];
        $this->BearerToken ="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMzODA4NzcsInNvdXJjZSI6InNyLWF1dGgtaW50IiwiZXhwIjoxNzI2NzIzMDU1LCJqdGkiOiJ6MXNwSzhiN1hROUN4RHBLIiwiaWF0IjoxNzI1ODU5MDU1LCJpc3MiOiJodHRwczovL3NyLWF1dGguc2hpcHJvY2tldC5pbi9hdXRob3JpemUvdXNlciIsIm5iZiI6MTcyNTg1OTA1NSwiY2lkIjoyMDg5ODA0LCJ0YyI6MzYwLCJ2ZXJib3NlIjpmYWxzZSwidmVuZG9yX2lkIjowLCJ2ZW5kb3JfY29kZSI6InVuaWNvbW1lcmNlIn0.BtDxOs3EIpJOu8x_3gZwj7WliuRQpfDG1ImkCPrNV8o";
    }
    public function inventryList(Request $request){
        // $shipment_id = "1713589000015424048";
        // $order_id ="1713589000015075020";
        // $result = $this->zohoService->updateShipmentStatus($shipment_id);
        // $result = $this->zohoService->test("salesorders/$order_id");
        // $result = json_decode($result->getContent(), true);  
        // dd($result['status_code']);
        $page = $request->input('page', 1); 
        $filter_by = $request->input('filter_by');  
        $sort_column = $request->input('sort_column_name'); 
        $sort_order = $request->input('sort_order'); 
        $per_page = $request->input('per_page'); 
        $filter_by = $filter_by ? "Status.$filter_by" : "Status.All" ;
        $queryParams = [
            'page' => $page,
            'per_page' => $per_page ?? 20,
            "filter_by" => $filter_by, 
            'sort_column' => $sort_column ?? 'created_time', 
            'sort_order' => $sort_order ?? 'D', 
            // "custom_fields"=> [],
            // 'search_criteria' => [
            //         [
            //         "column_name" => "Salesorder_Id",
            //         "search_text" => "SO-01013",
            //         "search_text_formatted" => "text",
            //         "comparator" => "equal",
            //     ]
            // ]
        ];
    
        
        $datas = $this->zohoService->fetchData('salesorders', $queryParams);
        // dd($datas);
        $items = collect($datas['salesorders']);
        $brandData = $items->map(function ($item) {
           $lable = BlueDartDetail::where('salesorder_id',$item['salesorder_id'])->first();
           $item['lable'] =$lable->id ?? false;
           $item['lable_url'] = $item['lable'] ? $this->getLable($lable->id) : false;
            return $item;
        });
        $totalPages = $datas['total_pages'] ?? 1;
        return view('pages.salesOrdersList', [
            'datas' => $brandData,
            'currentPage' => $page,
            'totalPages' => $totalPages
        ]);
    }

    public function checkServiceForPincode(Request $request){
        $datas = $this->zohoService->fetchData('salesorders/'.$request->salesorder_id);
        $data = $datas['salesorder'];
        $file = storage_path('app/salesorderData.json');
        file_put_contents($file, json_encode($data, true));
        $shipping_address = $data['shipping_address'];
        $response = $this->getServicesForPincode($shipping_address['zip']);
        return response()->json($response);
    }

    public function getServicesForPincode($pincode) 
    {
        $url = 'https://apigateway-sandbox.bluedart.com/in/transportation/finder/v1/GetServicesforPincode';
        $jwtToken = $this->jwtToken;  
        $file = storage_path('app/blueDartData.json');
        $fileData = json_decode(file_get_contents($file),true);
        $requestData = [
            'pinCode' => $pincode,  
            "profile" => $fileData['Profile']
        ];
        
        $response = Http::withHeaders([
            'JWTToken' => $jwtToken,
            'Content-Type' => 'application/json'
        ])->post($url, $requestData);
        
        if ($response->successful()) {
            $datas = $response->json();
            $data = $datas['GetServicesforPincodeResult'];
            if($data['Embargo']=='No'){
                $data = [
                            'air' => $data['eTailPrePaidAirOutound'] ?? 'No',
                            'surface' => $data['eTailPrePaidGroundInbound'] ?? 'No',
                            'dart' => $data['eTailPrePaidGroundOutbound'] ?? 'No',
                        ];
                return response()->json([
                    'status_code' => 1,
                    'status' => 'success',
                    'data'=> $data
                ]);
            }else{
                return response()->json([
                    'status_code' => 2,
                    'status' => 'error',
                    'message' => 'In Your Area Embargo Issue',
                ]);
            }
        }
        
         return response()->json([
            'status_code' => 2,
            'status' => 'error',
            'message' => 'No Services Available For The Selected Pincode',
            'data'=> $response->json()
         ]);
    }

    public function GenerateWayBill(Request $request) 
    {
        $url = 'https://apigateway-sandbox.bluedart.com/in/transportation/waybill/v1/GenerateWayBill';
        $jwtToken = $this->jwtToken;  
    
        $date = date("Y-m-d H:i:s");
        $date = Carbon::parse($date)->timestamp * 1000;
        $file = storage_path('app/blueDartData.json');
        $wayBillData = json_decode(file_get_contents($file),true);

        $salesOrderFile = storage_path('app/salesorderData.json');
        $salesorderData = json_decode(file_get_contents($salesOrderFile),true);
        $salesorder_id =$salesorderData['salesorder_id'];
        $salesorder_number =$salesorderData['salesorder_number'];
        $reference_number =$salesorderData['reference_number'];
        $customer_id =$salesorderData['customer_id'];
        $customer_name =$salesorderData['customer_name'];
        $created_by_name =$salesorderData['created_by_name'];
        $branch_id =$salesorderData['branch_id'];
        $branch_name =$salesorderData['branch_name'];
        $amount =$salesorderData['total'];
        $created_time =$salesorderData['created_time'];
        $shipping_address =$salesorderData['shipping_address'];
        $invoices =$salesorderData['invoices'];
        $contact_person_details =$salesorderData['contact_person_details'];
        $billing_address =$salesorderData['billing_address'];
        
        $wayBillData['Request']['Services']['Dimensions'] =[
                                                            "Breadth" => $request->breadth,
                                                            "Count" =>1,
                                                            "Height" => $request->height,
                                                            "Length" =>$request->length
                                                        ];
         //CreditReferenceNo is always unique
         $wayBillData['Request']['Services']['ActualWeight'] = $request->weight;
        $wayBillData['Request']['Services']['CreditReferenceNo'] = $reference_number; 
        $wayBillData['Request']['Services']['PickupDate'] ="/Date($date)/";

        $wayBillData['Request']['Services']['itemdtl'] =[];
        $wayBillData['Request']['Services']['ItemCount'] = $salesorderData['total_quantity'];
        foreach ($salesorderData['line_items'] as $lineItem) {
            $wayBillData['Request']['Services']['itemdtl'][] = [
                "CGSTAmount" => 0,
                "HSCode" => "",
                "IGSTAmount" => 0,
                "Instruction" => "",
                "InvoiceDate" => "/Date($date)/",
                "InvoiceNumber" => "",
                "ItemID" => substr($lineItem['item_id'], -15),
                "ItemName" => $lineItem['name'],
                "ItemValue" => 100,
                "Itemquantity" => $lineItem['quantity'],
                "PlaceofSupply" => "",
                "ProductDesc1" => "",
                "ProductDesc2" => "",
                "ReturnReason" => "",
                "SGSTAmount" => 0,
                "SKUNumber" => $lineItem['sku'],
                "SellerGSTNNumber" => "",
                "SellerName" => "",
                "SubProduct1" => "Test Sub 1",
                "SubProduct2" => "Test Sub 2",
                "TaxableAmount" =>$lineItem['line_item_taxes'][0]['tax_amount'] ?? 0,
                "TotalValue" => 100,
                "cessAmount" => "0.0",
                "countryOfOrigin" => "",
                "docType" => "",
                "subSupplyType" => 0,
                "supplyType" => ""
            ];
        }
        $phone =  $billing_address['phone'] ? $billing_address['phone'] : ($contact_person_details[0]['mobile'] ?? null);
        $wayBillData['Request']['Shipper'] =
        [
            "CustomerAddress1" => $shipping_address['address'] ?? '',
            "CustomerAddress2" => $shipping_address['street2'] ?? '',
            "CustomerAddress3" => "Test Cust Addr3",
            "CustomerAddressinfo" => "",
            "CustomerBusinessPartyTypeCode" => "",
            "CustomerCode" => "246525",
            "CustomerEmailID" => $contact_person_details[0]['email'] ?? null,
            "CustomerGSTNumber" => "",
            "CustomerLatitude" => "",
            "CustomerLongitude" => "",
            "CustomerMaskedContactNumber" => "",
            "CustomerMobile" => $phone,
            "CustomerName" => $customer_name,
            "CustomerPincode" => $shipping_address['zip'],
            "CustomerTelephone" => "",
            "IsToPayCustomer" => true,
            "OriginArea" => "DEL",
            "Sender" => $salesorderData['created_by_name'],
            "VendorCode" => ""
        ];


        switch ($request->service_type){
            case "air":
                $wayBillData['Request']['Services']['ProductCode'] = "A";
                break;
            case "surface":
                $wayBillData['Request']['Services']['ProductCode'] = "E";
                break;
            case "dart":
                $wayBillData['Request']['Services']['ProductCode'] = "E";
                $wayBillData['Request']['Services']['PackType'] = "L";
                break;
            default:
                $wayBillData['Request']['Services']['ProductCode'] = "A";
                break;
        }

        if($salesorderData['paid_status'] == "unpaid"){
           $wayBillData['Request']['Services']['SubProductCode'] = "C";
           $wayBillData['Request']['Services']['CollectableAmount'] = $salesorderData["total"];
        }else{
            $wayBillData['Request']['Services']['SubProductCode'] = "P";
        }
        // to be removed after the go live
        $wayBillData['Request']['Services']['SubProductCode'] = "P";
        $wayBillData['Request']['Services']['CollectableAmount'] = 0;

        
        // dd($wayBillData,$salesorderData);
        $response = Http::withHeaders([
            'JWTToken' => $jwtToken,
            'Content-Type' => 'application/json'
            ])->post($url, $wayBillData);
            
            // dd($response->json());
        if ($response->successful()) {
            $datas = $response->json();
            $data = $datas['GenerateWayBillResult'];
            $AWBNo = $data['AWBNo'];
            $file = storage_path("app/$AWBNo.json");
            file_put_contents($file, json_encode($datas, true));


            $blue =   BlueDartDetail::create([
                    'salesorder_id' => $salesorder_id,
                    'awb_no' => $data['AWBNo'] ?? 0,
                    'token_number' => $data['TokenNumber'] ?? 0,
                    'invoice_id' => $invoices[0]['invoice_id'] ?? 0,
                    'total_amount' => $salesorderData['total'],
                    'phone_number' => $phone,
                    'invoice_date' => $invoices[0]['date'] ?? 0,
                    'ship_to' => json_encode($shipping_address,true),
                    'cluster_code'=>$data['ClusterCode'],
                    'destination_area'=>$data['DestinationArea'],
                    'destination_location'=>$data['DestinationLocation'],
                    'total_quantity' => $salesorderData['total_quantity'],
                    'items_details' => json_encode($salesorderData['line_items'],true),
                    'order_date' =>$salesorderData['date']
                ]);
              if($data['AWBNo']){
                    $register_pickup = $this->registerPickup($data['AWBNo'],$wayBillData,$date);
                    $createPackageAndShipment = $this->zohoService->zohoUpdate($salesorder_id,$data['AWBNo']);
                    if($register_pickup && $createPackageAndShipment){
                        return response()->json([
                            'status_code' => 1,
                            'status' => 'success',
                            'message' => 'Your Shipment was Created successfully',
                            'data' => $register_pickup,
                        ]);
                    }else{
                        if(!$createPackageAndShipment){
                                return response()->json([
                                'status_code' => 2,
                                'status' => 'error',
                                'message' => 'Failed to Zoho Update.',
                                'data'=>$createPackageAndShipment
                                ]);
                        }
                        return response()->json([
                           'status_code' => 2,
                           'status' => 'error',
                           'message' => 'Failed to register pickup',
                           'data'=>$register_pickup
                        ]);
                    }
              }else{
                return response()->json([
                   'status_code' => 2,
                   'status' => 'error',
                   'message' => 'AWBNo is not registered',
                ]);
            }
        }
        $responseData =$response->json();
        return response()->json([
           'status_code' => 2,
           'status' => 'error',
           'message' => 'Try Again.',
           'message' =>$responseData['title'],
           'data' => $responseData,
        ]);
    }


    public function registerPickup($AWBNo, $wayBillData,$date){
        $url = 'https://apigateway-sandbox.bluedart.com/in/transportation/pickup/v1/RegisterPickup';
        $jwtToken = $this->jwtToken;
        $wayBillData['RegisterPickup']['AWBNo'] =[$AWBNo];
        $wayBillData['RegisterPickup']['ShipmentPickupDate'] ="/Date($date)/";
        // ShipmentPickupDate
        $requestData = [
            'request' =>$wayBillData['RegisterPickup'],  
            "profile" => $wayBillData['Profile']
        ];
        // return $requestData;
        $response = Http::withHeaders([
            'JWTToken' => $jwtToken,
            'Content-Type' => 'application/json'
        ])->post($url, $requestData);
        
        if ($response->successful()) {
            return true;
        }
        
        return $response->json();
    
    }

    public function getBlueDartJwtToken(){
        $url = 'https://apigateway-sandbox.bluedart.com/in/transportation/token/v1/login?ClientID=Hau8GA1vmvNUFD5rXZxNFBdl9rFLKGNG&clientSecret=lXvh9Re396Ab8GK0';
        $response = Http::get($url);
        $file = storage_path('app/blueDartJwtToken.json');
        file_put_contents($file, json_encode($response->json(), true));

        echo "JWT Token Created successfully.";
    }

    public function getLable($id)
    {
        $lable = BlueDartDetail::where('id',$id)->first();
        $label_url ='';
        if($lable->shipment_id){
            $api_url ="https://apiv2.shiprocket.in/v1/external/courier/generate/label";
            $data =[
                "shipment_id"=> ["632165518"]
            ];
            $response = Http::withHeaders([
                'Authorization' =>"Bearer ".$this->BearerToken ,
                'Content-Type' => 'application/json'
                ])->post($api_url, $data);
            $response = $response->json();
            $label_url = $response['label_url'];
        }else{
            $label_url = "/generate-invoice?salesorder_id=".$lable->salesorder_id;
        }

        return $label_url;

    }

    
}
