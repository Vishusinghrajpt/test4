<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use App\Services\ZohoInventoryService;
use App\Models\BlueDartDetail;

class ShiprocketController extends Controller
{
    protected $zohoService;
    protected $BearerToken;

    public function __construct(ZohoInventoryService $zohoService)
    {
        $this->zohoService = $zohoService;
        $this->BearerToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMzODA4NzcsInNvdXJjZSI6InNyLWF1dGgtaW50IiwiZXhwIjoxNzI2NzIzMDU1LCJqdGkiOiJ6MXNwSzhiN1hROUN4RHBLIiwiaWF0IjoxNzI1ODU5MDU1LCJpc3MiOiJodHRwczovL3NyLWF1dGguc2hpcHJvY2tldC5pbi9hdXRob3JpemUvdXNlciIsIm5iZiI6MTcyNTg1OTA1NSwiY2lkIjoyMDg5ODA0LCJ0YyI6MzYwLCJ2ZXJib3NlIjpmYWxzZSwidmVuZG9yX2lkIjowLCJ2ZW5kb3JfY29kZSI6InVuaWNvbW1lcmNlIn0.BtDxOs3EIpJOu8x_3gZwj7WliuRQpfDG1ImkCPrNV8o";
    }
    public function checkServiceForPincode(Request $request)
    {
        // dd($request->salesorder_id);
        if (!$request->salesorder_id){
            return response()->json([
                'status_code' => 2,
                'status' => 'error',
                'message' => 'Pin Code is required',
            ]);
        }

        $datas = $this->zohoService->fetchData('salesorders/'.$request->salesorder_id);
        $data = $datas['salesorder'];
        $file = storage_path('app/salesorderData.json');
        file_put_contents($file, json_encode($data, true));
        $shipping_address = $data['shipping_address'];


        $url = "https://apiv2.shiprocket.in/v1/external/courier/serviceability/";
        $data = array(
            "pickup_postcode" => 110070,
            "delivery_postcode" => $shipping_address['zip'],
            "cod" =>  0,
            "weight" =>$request->weight ?? ".1"
        );
        $response = Http::withHeaders([
            'Authorization' =>"Bearer ".$this->BearerToken ,
            'Content-Type' => 'application/json'
            ])->get($url, $data);

            $response = $response->json();
            if($response['status'] == 200){
                $data = $response['data'];
                $items = collect($data['available_courier_companies']);

                $companyData = $items->map(function ($item) {
                  $companyData ='<div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="service_type" id="'.$item['courier_company_id'].'" value="'.$item['courier_company_id'].'" required>
                        <label class="form-check-label" for="'.$item['courier_company_id'].'">'.$item['courier_name'].',   Charge: '. $item['freight_charge'].' </label>
                    </div>';
                    return $companyData;
                });
                return response()->json([
                    'status_code' => 3,
                    'status' => 'success',
                    'data'=> $companyData
                ]);
            } else {
                return response()->json([
                    'status_code' => 2,
                    'status' => 'error',
                    'message' => 'No Any Courier Company Available In Your Area',
                ]);
            }
    }

    public function create_shipment(Request $request)
    {

        $url = "https://apiv2.shiprocket.in/v1/external/orders/create/adhoc";

        $salesOrderFile = storage_path('app/salesorderData.json');
        $salesorderData = json_decode(file_get_contents($salesOrderFile),true);


        $salesorder_id =$salesorderData['salesorder_id'];
        $salesorder_number =$salesorderData['salesorder_number'];
        $reference_number =$salesorderData['reference_number'];
        $customer_id =$salesorderData['customer_id'];
        $customer_name =$salesorderData['customer_name'];
        $created_by_name =$salesorderData['created_by_name'];
        $branch_id =$salesorderData['branch_id'];
        $branch_name =$salesorderData['branch_name'];
        $amount =$salesorderData['total'];
        $created_time =$salesorderData['created_time'];
        $shipping_address =$salesorderData['shipping_address'];
        $invoices =$salesorderData['invoices'];
        $contact_person_details =$salesorderData['contact_person_details'];
        $billing_address =$salesorderData['billing_address'];
        $phone =  $billing_address['phone'] ? $billing_address['phone'] : ($contact_person_details[0]['mobile'] ?? null);
       
        foreach ($salesorderData['line_items'] as $lineItem) {
            $salesorderData['order_items'][] = 
            [ 
                "name"=>$lineItem['name'],
                "sku"=> $lineItem['sku'],
                "units"=>$lineItem['quantity'],
                "selling_price"=> $lineItem['rate'],
                "discount"=> $lineItem['discount'],
                "tax"=>$lineItem['line_item_taxes'][0]['tax_amount'] ?? 0,
                "hsn"=>$lineItem['hsn_or_sac']
              ];
        }
          
        $data = array(
            "order_id" => $salesorder_number,
            "order_date" => date("Y-m-d H:s", strtotime($created_time)),
            "channel_id" => "2380000",
            "billing_customer_name" => $customer_name,
            "billing_last_name" => '',
            "billing_address" => $shipping_address['address'],
            "billing_city" => $shipping_address['city'],
            "billing_pincode" => $shipping_address['zip'],
            "billing_state" => $shipping_address['state'],
            "billing_country" => $shipping_address['country'],
            "billing_email" => $contact_person_details[0]['email'] ?? null,
            "billing_phone" => $phone,
            "billing_alternate_phone" => "9199963838",
            "shipping_is_billing" => 1,
            "order_items" => $salesorderData['order_items'],
            "payment_method" => "Prepaid",
            "shipping_charges" => $salesorderData['shipping_charge'],
            "sub_total" => $salesorderData["sub_total"],
            "length" => $request->length,
            "breadth" => $request->breadth,
            "height" => $request->height,
            "weight" => $request->weight,
        );
      
        $response = Http::withHeaders([
            'Authorization' =>"Bearer ".$this->BearerToken ,
            'Content-Type' => 'application/json'
            ])->POST($url, $data);

            $response = $response->json();
            
        $file = storage_path("app/shiprocketResponse.json");
        file_put_contents($file, json_encode($response, true));
        // $response =  json_decode(file_get_contents($file),true);
            if($response['status_code'] == 1){
                $shipment_id = $response['shipment_id'];
                $courier_id = $request->service_type;
                $awbresponse = $this->generate_awb($shipment_id,$courier_id);
                if($awbresponse['awb_assign_status'] == 1){
                    $awbData = $awbresponse['response']['data'];
                    $awb_number = $awbData['awb_code'];
                    if($awb_number){
                        $delivery_method ="shiprocket";
                        $blue =   BlueDartDetail::create([
                            'salesorder_id' => $salesorder_id,
                            'awb_no' => $awb_number ?? 0,
                            'shipment_id' => $shipment_id ?? 0,
                            'invoice_id' => $invoices[0]['invoice_id'] ?? 0,
                            'total_amount' => $salesorderData['total'],
                            'phone_number' => $phone,
                            'invoice_date' => $invoices[0]['date'] ?? 0,
                            'ship_to' => json_encode($shipping_address,true),
                            'total_quantity' => $salesorderData['total_quantity'],
                            'items_details' => json_encode($salesorderData['line_items'],true),
                            'order_date' =>$salesorderData['date'],
                            'ship_by' =>$delivery_method
                        ]);
                       
                        $zoho =  $this->zohoService->zohoUpdate($salesorder_id,$awb_number,$delivery_method);
                        
                        return response()->json([
                            'status_code' => 1,
                            'status' => 'Success',
                            'message' => 'Your Shipment was Created successfully',
                        ]);
                    }

                }else{
                    return response()->json([
                       'status_code' => 2,
                       'status' => 'error',
                       'message' => 'Awb Generation Failed',
                    ]);
                }
            } else {
                return response()->json([
                   'status_code' => 2,
                   'status' => 'error',
                   'message' => 'Order Creation Failed',
                ]);

            }
    }


    // Generate AWB for Shipment
    public function generate_awb($shipment_id,$courier_id)
    {
        $url = "https://apiv2.shiprocket.in/v1/external/courier/assign/awb";

        $data =[
                "shipment_id" => $shipment_id,
                "courier_id" => $courier_id,
                "status"=> ""
        ];

        $response = Http::withHeaders([
                    'Authorization' =>"Bearer ".$this->BearerToken ,
                    'Content-Type' => 'application/json'
                ])->POST($url, $data);
    
        return $response->json();
    }

    public function cancelShipment(Request $request)
    {
        $lable = BlueDartDetail::where('salesorder_id',$request->salesorder_id)->first();
        $result = $this->zohoService->fetchData("salesorders/$request->salesorder_id");
        $shipment_id = $result['salesorder']['packages'][0]['shipment_id'] ?? false;
        $package_id = $result['salesorder']['packages'][0]['package_id'] ?? false;

        if($shipment_id && $package_id){
            $shipment = $this->zohoService->deleteShipmentOrder($shipment_id);
            $shipment = json_decode($shipment->getContent(), true);  
            if($shipment['status_code'] != 1){
                return response()->json([
                'status_code' => 2,
                'status' => 'error',
                'message' => 'Unable to cancel Shipment',
                ]);
            }
          
            $package =  $this->zohoService->deletePackage($package_id);
            $package = json_decode($package->getContent(), true);
            if($package['status_code'] != 1){
                return response()->json([
                'status_code' => 2,
                'status' => 'error',
                'message' => 'Unable to cancel Package',
                ]);
            }
            if($lable->ship_by == 'shiprocket'){
                $response =  $this->cancelShipmentFromShiprocket($lable->shipment_id);
                $response = json_decode($package->getContent(), true);
                if($response['status_code'] == 1){
                BlueDartDetail::where('salesorder_id',$request->salesorder_id)->delete();
                    return response()->json([
                    'status_code' => 1,
                    'status' => 'Success',
                    'message' => 'Shipment Cancelled and Package deleted successfully',
                    ]);
                } else {
                    return response()->json([
                    'status_code' => 2,
                    'status' => 'error',
                    'message' => 'Unable to delete Package',
                    ]);
                }
            }else{
                return response()->json([
                 'status_code' => 2,
                 'status' => 'error',
                 'message' => 'Unable to delete Package from Blue Dart',
                ]);

            }
        }else{
            return response()->json([
               'status_code' => 2,
               'status' => 'error',
               'message' => 'Unable to cancel Shipment',
            ]);
        }
    }

    public function cancelShipmentFromShiprocket($shipment_id)
    {
        $url = "https://apiv2.shiprocket.in/v1/external/orders/cancel/shipment";
        $data =[
                "shipment_id" => $shipment_id,
                "cancel_reason" => "Customer Requested",
        ];
        $response = Http::withHeaders([
                    'Authorization' =>"Bearer ".$this->BearerToken ,
                    'Content-Type' => 'application/json'
                ])->POST($url, $data);
        $response = $response->json();
        if($response['status_code'] == 1){
            return response()->json([
               'status_code' => 1,
               'status' => 'Success',
               'message' => 'Shipment Cancelled successfully',
            ]);
        } else {
            return response()->json([
               'status_code' =>2,
               'status' => 'error',
               'message' => 'Shipment Cancel Failed',
            ]);
        }
        return response()->json([
            'status_code' =>2,
            'status' => 'error',
            'message' => 'Shipment Cancel Failed',
         ]);

    }
}
