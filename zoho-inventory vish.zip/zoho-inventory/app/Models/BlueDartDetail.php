<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BlueDartDetail extends Model
{
    use HasFactory;
    protected $table = 'blue_dart_details';

    protected $fillable = [
        'salesorder_id',
        'awb_no',
        'token_number',
        'invoice_id',
        'total_amount',
        'phone_number',
        'invoice_date',
       'ship_to',
       'cluster_code',
       'destination_area',
       'destination_location',
       'total_quantity',
       'items_details',
       'order_date',
       'shipment_id',
       'ship_by'
    ];
}
