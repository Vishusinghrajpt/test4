<?php

namespace App\Services;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class ZohoInventoryService
{
    protected $client;
    protected $apiUrl;
    protected $organizationId;

    public function __construct()
    {
        $this->client = new Client();
        $this->apiUrl = 'https://inventory.zoho.in/api/v1/';
        $this->organizationId = "60027981548";
    }

    public function test(){
        return response()->json([
            'status_code' => 1,
            'status' =>'success',
            'message' => 'Your Package Was Deleted successfully in Zoho',
         ]);
    }

    public function getAccessToken()
    {
        $url = "https://accounts.zoho.in/oauth/v2/token";
        $clientId = '1000.4XILKCLVM4T4YBSNW8SL5DKHDHSYZY';
        $clientSecret = 'ef6690ef9f86d4e294402f9bb050770d5399d58c68';
        $refreshToken = '1000.95900529c1ead5c3f20fe4b16e90535e.9f4f257a419d3a5505c157a1f8181665';
        // return $refreshToken;
        $file = storage_path('app/accessToken.json');
        $fileData = json_decode(file_get_contents($file),true);
        if(time() >= $fileData['expires_in']){ 
            try {
                $response = $this->client->request('POST', $url, [
                    'form_params' => [
                        'refresh_token' => $refreshToken,
                        'client_id' => $clientId,
                        'client_secret' => $clientSecret,
                        'grant_type' => 'refresh_token',
                    ],
                ]);

                $data = json_decode($response->getBody(), true);
                $data['expires_in'] = $data['expires_in']+ time();
                file_put_contents($file, json_encode($data, true));
                return $data['access_token'];

            } catch (\Exception $e) {
                Log::error('Failed to retrieve Zoho access token: ' . $e->getMessage());
                return null;
            }
        }
        return $fileData['access_token'];
    }


    public function fetchData($endpoint, $params = [])
    {
        $accessToken = $this->getAccessToken();
        try {
            $response = $this->client->request('GET', "https://www.zohoapis.in/inventory/v1/$endpoint?organization_id=60027981548", [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                ],
                'query' => $params,
            ]);
            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('Zoho API Request Failed: ' . $e->getMessage());
            return null;
        }
    }

    public function createPackage($data,$salesorder_id)
    {
        $accessToken = $this->getAccessToken();
        $apiUrl ="https://www.zohoapis.in/inventory/v1/packages?organization_id=60027981548&salesorder_id=$salesorder_id"; 
        // return 
        try {
            $response = $this->client->request('POST', $apiUrl, [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('Zoho API Request Failed (Package Creation): ' . $e->getMessage());
            return $e->getMessage();
        }
    }

    public function createShipment($data, $endpoint)
    {
        $accessToken = $this->getAccessToken();
        $apiUrl = "https://www.zohoapis.in/inventory/v1/shipmentorders?organization_id=60027981548$endpoint"; // Replace with the correct endpoint

        try {
            $response = $this->client->request('POST', $apiUrl, [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                    'Content-Type' => 'application/json',
                ],
                'json' => $data, // Pass the shipment data here
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('Zoho API Request Failed (Shipment Creation): ' . $e->getMessage());
            return $e->getMessage();
        }
    }

    public function updateShipmentStatus($shipmentOrderId, $status = 'delivered')
    {
          $url = "https://www.zohoapis.in/inventory/v1/shipmentorders/{$shipmentOrderId}/status/delivered?organization_id={$this->organizationId}";

            $accessToken = $this->getAccessToken();
            try {
                $response = $this->client->request('POST', $url, [
                    'headers' => [
                        'Authorization' => "Zoho-oauthtoken $accessToken",
                        'Content-Type' => 'application/json',
                    ]
                ]);

                $data = json_decode($response->getBody(), true);
                return $data;

            } catch (\Exception $e) {
                Log::error('Failed to update shipment status in Zoho: ' . $e->getMessage());
                return $e->getMessage();
            }
    }

    public function deleteShipmentOrder($shipmentOrderId)
    {
        $url = "https://www.zohoapis.in/inventory/v1/shipmentorders/{$shipmentOrderId}?organization_id={$this->organizationId}";
        $accessToken = $this->getAccessToken();

        try {
            $response = $this->client->request('DELETE', $url, [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                ]
            ]);

            return response()->json([
                'status_code' => 1,
                'status' =>'success',
                'message' => 'Your Shipment Order Was Deleted successfully in Zoho',
                'data' => $response,
             ]); 
        } catch (\Exception $e) {
            Log::error('Failed to delete shipment order from Zoho: '. $e->getMessage());
            return $e->getMessage();
        }
    
    }

    public function deletePackage($packageId)
    {
        $url = "https://www.zohoapis.in/inventory/v1/packages/{$packageId}?organization_id={$this->organizationId}";
        $accessToken = $this->getAccessToken();

        try {
            $response = $this->client->request('DELETE', $url, [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                ]
            ]);
            return response()->json([
                'status_code' => 1,
                'status' =>'success',
                'message' => 'Your Package Was Deleted successfully in Zoho',
                'data' => $response,
             ]);
        } catch (\Exception $e) {
            Log::error('Failed to delete package from Zoho: '. $e->getMessage());
            return $e->getMessage();
        }
    }


    public function zohoUpdate($salesorder_id,$AWBNo,$delivery_method='Blue Dart')
    {
        $datas = $this->fetchData("salesorders/$salesorder_id");
        $data =$datas['salesorder'];
        $packageFile = storage_path('app/packageBodyData.json');
        $packageData = json_decode(file_get_contents($packageFile),true);
        $packageData['line_items'] = $data['line_items'];
        $packageData['date'] =date("Y-m-d");
        $packageData['line_items'] = array_map(function($item) {
            if(isset($item['line_item_id'])) {
                $item['so_line_item_id'] = $item['line_item_id'];
                unset($item['line_item_id']);
            }
            return $item;
        }, $packageData['line_items']);
        $packageCreatedFile = storage_path('app/packageCreatedData.json');
        $shipmentData = [];
        $shipmentData['shipment_number'] ='';
        $shipmentData['delivery_method'] =$delivery_method;
        $shipmentData['tracking_number'] = $AWBNo;
        $shipmentData['ignore_auto_generation'] =True;
        $shipmentData['date'] =date("Y-m-d");
        $packageCreatedData = $this->createPackage($packageData,$salesorder_id);
        file_put_contents($packageCreatedFile, json_encode($packageCreatedData, true));
        $createShipmentData = [];
        if($packageCreatedData['package']){
            $package = $packageCreatedData['package'];
            $package_id = $package['package_id'];
            $endPoint ="&salesorder_id=$salesorder_id&package_ids=$package_id";
            $createShipmentData = $this->createShipment($shipmentData,$endPoint);

            return response()->json([
                'status_code' => 1,
                'status' =>'success',
                'message' => 'Package and Shipment created successfully in Zoho',
                'package_id' => $package_id,
                'data' => $createShipmentData,
             ]);
        }else{
            return response()->json([
                'status_code' => 2,
                'status' => 'error',
                'message' => 'Failed to create package in Zoho',
             ]);
        }
        return response()->json([
            'status_code' => 1,
            'status' => 'error',
            'message' => 'Failed to create package in Zoho',
         ]);
    }

    public function getAccessTokenFromAuthCode()
    {
        $authorizationCode ="1000.540b049072c790b24fb442580aca9d5f.d02cbb52abfa005bad29bb340432d3bd";
        $url = "https://accounts.zoho.in/oauth/v2/token";
        $clientId = '1000.4XILKCLVM4T4YBSNW8SL5DKHDHSYZY';
        $clientSecret = 'ef6690ef9f86d4e294402f9bb050770d5399d58c68';
        $redirectUri = 'https://servdharm.com/';
        
        // return $authorizationCode;
        try {
            $response = $this->client->request('POST', $url, [
                'form_params' => [
                    'code' => $authorizationCode,
                    'client_id' => $clientId,
                    'client_secret' => $clientSecret,
                    'redirect_uri' => $redirectUri,
                    'grant_type' => 'authorization_code',
                ],
            ]);

            $data = json_decode($response->getBody(), true);
            // return $data;
            // $accessToken = $data['access_token'];
            // $refreshToken = $data['refresh_token'];

            
            // return ['access_token' => $accessToken, 'refresh_token' => $refreshToken];

        } catch (\Exception $e) {
            return  'Failed to retrieve Zoho tokens: ' . $e->getMessage();
             
        }
    }

    

}
