<style>
  table {
    font-family: "Roboto", sans-serif;

  }
</style>
<table cellspacing="0" cellpadding="5" width="100%" border="1px">
  <tr>
    <td>
      <strong>Ship to</strong>: <?php echo e($ship_to ?? ''); ?><br />Mob: <?php echo e($phone ?? ''); ?>

    </td>
    <td align="center">
      <img src="https://servdharm.com/cdn/shop/files/servdharm-logo_600x.webp" alt="Logo">
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center" style="text-align: center;">
      <p>
        <strong>Bluedart: <?php echo e($awb_no ?? ''); ?></strong>
      </p>
      <div style="margin: 0 auto; display: inline-block;">
        <?php echo DNS1D::getBarcodeHTML($awb_no, 'C39'); ?>

      </div>
    </td>
  </tr>
  <tr>
    <td align="center">
      <strong>
        Amount to be collected<br />COD<br />Rs <?php echo e($amount ?? 0); ?>.00<br />
        (<?php echo e($amountInString ?? ''); ?>)
      </strong>
    </td>
    <td>
      <table border="0" width="100%" cellspacing="0" cellpadding="3">
        <tr>
          <td><strong>Route Code:</strong></td>
          <td align="right"><?php echo e($route ?? ''); ?></td>
        </tr>
        <tr>
          <td><strong>Order Date:</strong></td>
          <td align="right"><?php echo e(date('M d, Y', strtotime($order_date)) ?? ''); ?></td>
        </tr>
        <tr>
          <td><strong>Invoice Number:</strong></td>
          <td align="right"><?php echo e($invoice_id ?? ''); ?></td>
        </tr>
        <tr>
          <td><strong>Invoice Date:</strong></td>
          <td align="right"><?php echo e(date('M d, Y', strtotime($invoice_date)) ?? ''); ?></td>
        </tr>
        <tr>
          <td><strong>Pieces:</strong></td>
          <td align="right"><?php echo e($total_quantity ?? ''); ?></td>
        </tr>
      </table>
    </td>

  </tr>
  <tr>
    <td colspan="2" align="center">
      Order Id: <?php echo e($salesorder_id ?? ''); ?>

    </td>
  </tr>
  <tr>
    <td colspan="2" height="200px">
      <table class="table table-bordered" width="100%" cellspacing="0" cellpadding="3">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>SKU</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = json_decode($items_details, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $taxtData = $item['line_item_taxes'][0] ?? null;
          $total_amount =$item['item_total']+ ($taxtData['tax_amount'] ?? 0);
          ?>
          <tr>
            <td><?php echo e($item['name'] ?? 'name'); ?></td>
            <td><?php echo e($item['sku'] ?? 'sku'); ?></td>
            <td><?php echo e($item['quantity'] ?? 'qty'); ?></td>
            <td><?php echo e(number_format($item['rate'],2) ?? 'rate'); ?></td>
            <td><?php echo e(number_format($total_amount,2) ?? 'total'); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </td>
  </tr>
  <tr>
    <td>Order Total: </td>
    <td align="right">Rs <?php echo e(number_format($amount,2) ?? ''); ?></td>
  </tr>
  <tr>
    <td colspan="2">
      <strong>
        <p>Return Address:
      </strong> D53, Nangal Dewat, Sector D, Vasant Kunj, New Delhi, South
      West Delhi, South West Delhi, Delhi, India, 110070</p>
      <p><strong>GSTIN No.:</strong> 07AASFT1911F1Z5</p>
    </td>
  </tr>
</table><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/pdf/invoice.blade.php ENDPATH**/ ?>