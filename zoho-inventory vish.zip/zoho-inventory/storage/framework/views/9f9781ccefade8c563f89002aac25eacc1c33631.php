
<?php $__env->startSection('title'); ?> Zoho + Blue Dart <?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style type="text/css">
    .table-bordered>thead>tr>th a {
        display: flex;
        justify-content: space-between;
        color: black;
    }

    .ShorderByStatusSec {
        display: flex;
        justify-content: space-between;
        align-items: center;

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 0;

            label {
                width: 233px;
                margin-bottom: 0;
            }
        }
    }

    .alert {
        padding: 0px 5px;
        margin: 0;
    }
    .dropdown-menu > li > a{
        color:white !important;
    }
    .dropdown-menu > li > a:hover, .dropdown-menu > li > a:focus{
        color: black !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div id="page-wrapper1">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="panel panel-default">
                    <div class="panel-heading ShorderByStatusSec">
                        List Of Orders
                        <div class="form-group">
                            <label for="ShorderByStatus">Filter By Zoho Status:</label>
                            <select class="form-control" id="ShorderByStatus" placeholder="" onchange="shortByStatus(this.value)">
                                <option value="">Select Order Status</option>
                                <option value="Confirmed">Confirmed</option>
                                <option value="Fulfilled">Fulfilled</option>
                                <option value="Void">Void</option>
                                <option value="Draft">Draft</option>
                            </select>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">

                            <table class="table table-striped table-bordered table-hover" data-show-toggle="true">
                                <thead>
                                    <tr>
                                        <th>
                                            <a class="ShortBy" href="javascript:void(0)" onclick="sortBy('salesorder_number')">
                                                Sales Order Id
                                                <i id="icon_salesorder_number" class="fa fa-sort-asc"></i>
                                            </a>
                                        </th>
                                        <th>
                                            <a class="ShortBy" href="javascript:void(0)" onclick="sortBy('customer_name')">
                                                Customer Name
                                                <i id="icon_customer_name" class="fa fa-sort-asc"></i>
                                            </a>
                                        </th>
                                        <th>Email</th>
                                        <th>
                                            <a class="ShortBy" href="javascript:void(0)" onclick="sortBy('total')">
                                                Total Amount
                                                <i id="icon_total" class="fa fa-sort-asc"></i>
                                            </a>
                                        </th>
                                        <th>Shipping Status</th>
                                        <th>Zoho Status</th>
                                        <th style="width: 100px;">Manage Shipment</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $salesorder_id = $data['salesorder_id'];
                                    ?>
                                    <tr>
                                        <td>#<?php echo e($data['salesorder_number'] ?? ''); ?></td>
                                        <td><?php echo e($data['customer_name'] ?? ''); ?></td>
                                        <td><?php echo e($data['email'] ?? ''); ?></td>
                                        <td>Rs. <?php echo e(number_format($data['total'],2) ?? ''); ?></td>
                                        <td><?php echo e($data['shipped_status'] ?? ''); ?></td>
                                        <td><?php echo e($data['status'] ?? ''); ?></td>
                                        <td align="center">
                                            <?php if($data['invoiced_status'] == 'invoiced' && ($data['order_status'] == 'confirmed' || $data['order_status'] == 'closed') ): ?>
                                            <?php if($data['lable']): ?>

                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                                                    Action
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li class="btn">
                                                        <a class="btn btn-primary text-white" href="<?php echo e($data['lable_url']); ?>">
                                                            Download Label
                                                        </a>
                                                    </li>
                                                    <li class="btn">
                                                        <a class="btn btn-danger" href="javascript:void(0)" onclick="cancelShipment('<?php echo e($salesorder_id); ?>')">
                                                            Cancel Shipment
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <?php else: ?>
                                            <?php if($data['shipped_status'] == 'pending'): ?>
                                            <!-- <button class="btn btn-success" onclick="shipModel('<?php echo e($salesorder_id); ?>')" style="margin-bottom:3px;">Ship By Blue Dart</button>
                                                     <button class="btn btn-info" onclick="shipByShiprocket('<?php echo e($salesorder_id); ?>')">Ship By Shiprocket</button> -->
                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                                                    Ship
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li class="btn"><a class="btn btn-success" href="javascript:void(0)" onclick="shipModel('<?php echo e($salesorder_id); ?>','blueDart')">Ship By Blue Dart</a></li>
                                                    <li class="btn"><a class="btn btn-info" href="javascript:void(0)" onclick="shipByShiprocket('<?php echo e($salesorder_id); ?>')">Ship By Shiprocket</a></li>
                                                </ul>
                                            </div>
                                            <?php else: ?>
                                            <span class="alert alert-warning">Shipped</span>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($data['invoiced_status'] != 'invoiced'): ?>
                                            <span class="alert alert-info">Not Invoiced</span>
                                            <?php elseif($data['order_status'] != 'confirmed'): ?>
                                            <span class="alert alert-warning">Order Not confirmed</span>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination" style="display:flex;justify-content:end;">
                                <?php if($currentPage > 1): ?>
                                <a class="btn btn-success" href="javascript:void(0)" style="margin-right: 10px;" onclick="pagination('<?php echo e($currentPage -1); ?>')">Previous</a>
                                <?php endif; ?>

                                <?php if($currentPage): ?>
                                <a class="btn btn-success ms-3" href="javascript:void(0)" onclick="pagination('<?php echo e($currentPage + 1); ?>')">Next</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.shipModal','data' => ['message' => 'test','id' => 'blueDart','title' => 'Blue Dart Shipment','action' => ''.e(route('ship_blue_dart')).'']]); ?>
<?php $component->withName('shipModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['message' => 'test','id' => 'blueDart','title' => 'Blue Dart Shipment','action' => ''.e(route('ship_blue_dart')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<!-- shipByShiprocket -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.shipModal','data' => ['message' => 'test','id' => 'shiprocket','title' => 'Shiprocket Shipment','action' => ''.e(route('GetServices')).'']]); ?>
<?php $component->withName('shipModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['message' => 'test','id' => 'shiprocket','title' => 'Shiprocket Shipment','action' => ''.e(route('GetServices')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
    function shipByShiprocket(salesorder_id, modal_id = "shiprocket") {
        $('.checkBoxGroup_' + modal_id).html('');
        $('#salesorder_id_' + modal_id).val(salesorder_id);
        $('.available_' + modal_id).hide();
        $('#submit_' + modal_id).html('Check Courier Options')
        $('#form_' + modal_id).attr('action', "<?php echo e(route('GetServices')); ?>")
        $('#modal_' + modal_id).modal('show');
    }

    function shipModel($data, modal_id) {
        $.ajax({
            url: "<?php echo e(route('GetServicesforPincode')); ?>",
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                salesorder_id: $data,
            },
            success: function(response) {
                var data = response.original;
                var checkBoxGroup = '';
                if (data.status_code == 2) {
                    Swal.fire({
                        icon: 'error',
                        title: data.data.title ?? 'Error',
                        text: 'No Services Available For The Selected Pincode.',
                    });
                } else {
                    if (data.data.air === "Yes") {
                        checkBoxGroup += `<div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidAirOutbound" value="air" required>
                        <label class="form-check-label" for="eTailPrePaidAirOutbound">Air</label>
                    </div>`;
                    }

                    if (data.data.surface === "Yes") {
                        checkBoxGroup += `<div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundInbound" value="surface" required>
                        <label class="form-check-label" for="eTailPrePaidGroundInbound">Ground / Surface</label>
                    </div>`;
                    }

                    if (data.data.dart === "Yes") {
                        checkBoxGroup += `<div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundOutbound" value="dart" required>
                        <label class="form-check-label" for="eTailPrePaidGroundOutbound">Dart</label>
                    </div>`;
                    }
                    $('.checkBoxGroup_' + modal_id).html(checkBoxGroup);
                    $('#modal_' + modal_id).modal('show');
                }

            },
            error: function(xhr, status, error) {
                console.log('Error: ', error);
                let response = xhr.responseJSON;
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message || 'An unexpected error occurred.',
                });
            }
        });
    }

    function formSubmit(formData, e, modal_id) {
        e.preventDefault();
        var serilizFormData = $(formData).serialize();
        $.ajax({
            url: formData.action,
            type: formData.method,
            data: serilizFormData,
            success: function(response) {
                var massage = response.message;
                if (response.status_code == 1) {
                    $('#modal' + modal_id).modal('hide');
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: massage ?? 'Order has been shipped successfully.',
                    }).then(() => {
                        location.reload();
                    });
                } else if (response.status_code == 3) {
                    $('.available_' + modal_id).show();
                    $('#submit_' + modal_id).html('Create Shipment')
                    $('.checkBoxGroup_' + modal_id).html(response.data);
                    $('#form_' + modal_id).attr('action', "<?php echo e(route('ship_by_shiprocket')); ?>")
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: massage ?? 'An unexpected error occurred.',
                    });
                }
            },
            error: function(xhr, status, error) {
                console.log('Error: ', error);
                let response = xhr.responseJSON;
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: response.message || 'An unexpected error occurred.',
                });
            }
        });
    }



    let currentSortColumn = "";
    let currentSortOrder = "A";

    function getURLParameter(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    function initializeSorting() {
        currentSortColumn = getURLParameter('sort_column_name') || "";
        currentSortOrder = getURLParameter('sort_order') || "A";

        if (currentSortColumn) {
            updateSortIcons(currentSortColumn, currentSortOrder);
        }
    }

    function sortBy(column) {
        if (currentSortColumn === column) {
            currentSortOrder = currentSortOrder === "A" ? "D" : "A";
        } else {
            currentSortOrder = "A";
        }
        currentSortColumn = column;

        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('sort_column_name', column);
        urlParams.set('sort_order', currentSortOrder);

        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.location.href = newUrl;
    }

    function updateSortIcons(column, sortOrder) {
        const icon = document.getElementById(`icon_${column}`);
        if (sortOrder === "A") {
            icon.classList.add("fa-sort-asc");
        } else {
            icon.classList.add("fa-sort-desc");
        }
    }

    function shortByStatus(value) {
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('filter_by', value);
        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.location.href = newUrl;
    }

    function pagination(page) {
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('page', page);
        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.location.href = newUrl;
    }
    window.onload = initializeSorting;

    function cancelShipment(salesorder_id)
    {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, cancel it!'
        }).then((result) => {
            if (result.isConfirmed) {
                var url = "<?php echo e(route('cancel_shipment', ['salesorder_id' => '__ID__'])); ?>"; 
                url = url.replace('__ID__', salesorder_id); 
                window.location.href = url;
                // window.location.href = "<?php echo e(route('cancel_shipment', ['salesorder_id' => "+salesorder_id+"])); ?>";
            }
        });
    }
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/pages/salesOrdersList.blade.php ENDPATH**/ ?>