<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/">Zoho + Blue Dart</a>
    </div>

    <?php if(auth()->guard()->check()): ?>
    <div style="color: white;
            padding: 15px 50px 5px 50px;
            float: right;
            font-size: 16px;">
        <form method="post" action="<?php echo e(route('logout')); ?>" id="logoutForm">
            <?php echo csrf_field(); ?>
            <a href="javascript:;" onclick="document.getElementById('logoutForm').submit()" class="btn btn-danger square-btn-adjust">Logout</a>
        </form>

    </div>
    <?php else: ?>
    
    <?php endif; ?>
</nav><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/include/topNavBar.blade.php ENDPATH**/ ?>